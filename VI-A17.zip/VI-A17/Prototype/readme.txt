To run visualization, you should open a terminal window with he following command:

python -m http.server 8888

and then open the Google Chrome web browser and type localhost:8888