var i = 1;

function updateVis() {
	console.log("Update");
	lol += 1;
}